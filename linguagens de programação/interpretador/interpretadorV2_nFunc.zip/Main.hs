module Main where

import Lexer
import Parser
import Interpreter
import TypeChecker

main = getContents >>= print . typecheck . step . parser . lexer 